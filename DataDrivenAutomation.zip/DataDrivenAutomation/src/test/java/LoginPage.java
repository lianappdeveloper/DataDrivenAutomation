import com.opencsv.CSVReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.testng.Assert.assertEquals;


public class LoginPage extends LoginElements {

    @DataProvider(name = "user-ids-passwords-csv-data-provider")
    public Iterator<String[]> userIdsAndPasaswordCSVDataProvider() {
        return readFromCSVFile(".\\src\\test\\login-data.csv").iterator();
    }

    @Test
    public void test() throws IOException {
        List<String[]> data = readFromCSVFile(".\\src\\test\\login-data.csv");
        for (String[] row : data) {
            System.out.println(Arrays.toString(row));
        }
    }

    private List<String[]> readFromCSVFile(String csvFilePath) {
        try {
            CSVReader reader = new CSVReader(new FileReader(csvFilePath));
            List<String[]> data = reader.readAll();
            return data;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @Test(dataProvider = "user-ids-passwords-csv-data-provider")
    public void Login(String userId, String password) {
        driver.get("https://the-internet.herokuapp.com/login");
        driver.findElement(By.id("username")).sendKeys(userId);
        WebElement passwordElement = driver.findElement(By.id("password"));
        passwordElement.sendKeys(password);
        passwordElement.submit();
        System.out.println(driver.findElement(By.id("flash-messages")).getText());

    }

    @Test
    public void InvalidPassword() {
        driver.get("https://the-internet.herokuapp.com/login");
        driver.findElement(By.id("username")).sendKeys("tomsmith");
        WebElement passwordElement = driver.findElement(By.id("password"));
        passwordElement.sendKeys("1234");
        passwordElement.submit();
        WebElement errorMessageText = driver.findElement(By.id("flash-messages"));
        assertEquals(errorMessageText.getText(), "Your password is invalid!\n" +
                "×");

    }
}
